# Chart Converter Offline (Android)

نسخة Android أوفلاين من أداة **Psych to Base Game 0.2.0 Chart Converter** التي أرسلها المستخدم.

## الوظائف
- تحويل Psych Engine charts.
- تحويل V-Slice charts.
- تحويل Codename Engine charts.
- فتح ملفات JSON من مدير ملفات Android.
- حفظ النتيجة عبر نافذة اختيار مكان الحفظ.
- لا توجد طلبات شبكة أو اعتماد على CDN أو مكتبات خارجية وقت التشغيل.

## بناء APK محلياً
يتطلب JDK 17 و Android SDK مع منصة Android 35:
```bash
gradle assembleDebug
```
الناتج:
`app/build/outputs/apk/debug/app-debug.apk`

## البناء عبر GitHub
1. ارفع محتويات هذا المشروع إلى مستودع GitHub جديد.
2. افتح تبويب **Actions**.
3. شغّل **Build Android APK** عبر Run workflow، أو ادفع commit إلى `main`.
4. افتح نتيجة التشغيل الناجح ثم نزّل artifact باسم `ChartConverterOffline-debug`.
5. فك ضغط artifact لتحصل على `app-debug.apk`.

## التوافق
- الحد الأدنى المعلن في المشروع Android 5.0 (API 21).
- مصمم ليعمل على Android 8 وما بعده.
- التطبيق يعالج الملفات محلياً ولا يحتاج إذن الإنترنت.

## ملاحظة مهمة
تم الإبقاء على خوارزميات التحويل الموجودة في ملف HTML الأصلي، مع تهيئة الواجهة للهاتف وربط اختيار الملفات والحفظ بواجهات Android الأصلية. هذا يحوّل الموقع إلى تطبيق أوفلاين، لكنه لا يعني أن كل حالات الشارتات الممكنة تم اختبارها؛ اختبر ملفات من كل صيغة قبل الاعتماد على نتائجها.


## App icon
The launcher icon uses the image supplied by the project owner. Legacy PNG launcher icons are included for older Android versions, with adaptive icons for Android 8.0 and newer.
